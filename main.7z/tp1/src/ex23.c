#include <stdio.h>

int main() {
	printf("%d\n", 4*18-198%10);
	printf("%d\n", (7+3)<=10);
	printf("%d\n", (8+4)>3 && 3>2);
	printf("%d\n",(37+18%4)/4);
	printf("%d\n",((3>7)||(3<=7))&&(7!=10));
	printf("%d\n",8==9);
	
	return 0;
}
