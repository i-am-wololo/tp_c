#include <stdio.h>

int main() {
	int a;
	printf("entrez entier: ");
	scanf("%d", &a);
	printf("%d", a%2);
	return 0;
}
