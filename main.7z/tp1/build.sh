#!/bin/bash
#gcc src/tp1-ex12.c -o ./dist/tp1-ex12
#./dist/tp1-ex12
#echo
#
#echo exercice 2.1
#gcc src/ex21.c -o ./dist/ex21
#./dist/ex21
#echo code retour de 5
#echo
#
#echo exercice 2.2
#gcc src/ex22.c -o ./dist/ex22
#./dist/ex22
#echo
#
#echo exercice 2.3
#gcc src/ex23.c -o ./dist/ex23
#./dist/ex23
#echo
#
#echo exercice 2.4
#gcc src/ex24.c -o ./dist/ex24
#./dist/ex24
#echo
#
#echo exercice 2.5
#gcc src/ex25.c -o ./dist/ex25
#./dist/ex25
#echo
#
#echo exercice 3.1
#gcc src/ex31.c -o ./dist/ex31
#./dist/ex31
#echo
#
#echo exercice 3.2
#gcc src/ex32.c -o ./dist/ex32
#./dist/ex32
#echo
#
#echo exercice 3.3
#gcc src/ex33.c -o ./dist/ex33
#./dist/ex33
#echo
#
#echo exercice 4.1
#gcc src/ex41.c -o ./dist/ex41
#./dist/ex41
#echo
#
#echo exercice 4.2
#gcc src/ex42.c -o ./dist/ex42
#./dist/ex42
#echo

#echo exercice 4.3
#gcc src/ex43.c -o ./dist/ex43
#./dist/ex43
#echo

#echo exercice 4.4
#gcc src/ex44.c -o ./dist/ex44
#./dist/ex44
#echo

echo exercice 4.5
gcc src/ex45.c -o ./dist/ex45
./dist/ex45
echo
