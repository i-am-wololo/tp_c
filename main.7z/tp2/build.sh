#!/bin/bash

#echo exercice 1.1
#gcc src/ex11.c -o ./dist/ex11
#./dist/ex11
#echo

#echo exercice 1.2
#gcc src/ex12.c -o ./dist/ex12
#./dist/ex12
#echo


#echo exercice 1.3
#gcc src/ex13.c -o ./dist/ex13
#./dist/ex13
#echo


echo exercice 31
gcc src/ex31.c -o ./dist/ex31
./dist/ex31
echo


